#include <iomanip>
#include <iostream>
using namespace std;

int main() {
    const long long farePaise = 3000; // Rs 30.00
    const long long counts[] = {20000, 500000, 3000000};

    cout << fixed << setprecision(2);
    for (long long n : counts) {
        long long exactPaise = farePaise * n;
        double rupees = 30.0 * static_cast<double>(n);
        cout << n << " journeys: integer-paise Rs "
             << static_cast<double>(exactPaise)/100.0
             << ", double Rs " << rupees << '\n';
    }

    long long networkPaise = farePaise * 3000000LL;
    cout << "Network total in paise: " << networkPaise << '\n';
    cout << "Exceeds INT_MAX: " << (networkPaise > 2147483647LL ? "Yes" : "No") << '\n';
    cout << "Use long long for accumulated paise.\n";
}
