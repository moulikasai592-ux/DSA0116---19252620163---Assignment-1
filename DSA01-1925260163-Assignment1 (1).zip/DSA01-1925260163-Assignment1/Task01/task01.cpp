#include <iostream>
#include <string>
using namespace std;

class SmartCard {
    long long balancePaise;
public:
    SmartCard(long long amount) : balancePaise(amount) {}
    bool canTravel(long long farePaise) const {
        return balancePaise - farePaise >= 5000;
    }
    void deduct(long long farePaise) {
        if (canTravel(farePaise)) balancePaise -= farePaise;
    }
    long long balance() const { return balancePaise; }
};

int main() {
    SmartCard card(10000);
    const long long innerFare = 1000;
    cout << "Initial balance: Rs 100.00\n";
    if (card.canTravel(innerFare)) {
        card.deduct(innerFare);
        cout << "Inner-zone journey accepted\n";
    }
    cout << "Remaining balance: Rs " << card.balance()/100 << "."
         << (card.balance()%100 < 10 ? "0" : "") << card.balance()%100 << '\n';
    cout << "Minimum balance rule: Rs 50.00\n";
}
