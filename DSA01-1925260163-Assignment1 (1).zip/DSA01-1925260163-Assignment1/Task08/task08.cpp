#include <iomanip>
#include <iostream>
#include <limits>
using namespace std;

int main() {
    int hour;
    double recharge;
    cout << "Enter journey hour (0-23): ";
    while (!(cin >> hour) || hour < 0 || hour > 23) {
        cout << "Invalid hour. Enter a number from 0 to 23: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    cout << "Enter recharge amount in rupees: ";
    while (!(cin >> recharge) || recharge < 0) {
        cout << "Invalid recharge. Enter a non-negative amount: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    cout << fixed << setprecision(2);
    cout << "Journey hour: " << hour << '\n';
    cout << "Recharge amount: Rs " << recharge << '\n';
    cout << "Input accepted successfully\n";
}
