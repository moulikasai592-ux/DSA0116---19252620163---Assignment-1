#include <iostream>
using namespace std;

constexpr long long MIN_REMAINING = 5000;

// Procedural style
bool proceduralCanTravel(long long balance, long long fare) {
    return balance - fare >= MIN_REMAINING;
}
void proceduralDeduct(long long& balance, long long fare) {
    if (proceduralCanTravel(balance, fare)) balance -= fare;
}

// Object-oriented style
class SmartCard {
private:
    long long balance;
public:
    explicit SmartCard(long long initial) : balance(initial) {}
    bool canTravel(long long fare) const {
        return balance - fare >= MIN_REMAINING;
    }
    bool deduct(long long fare) {
        if (!canTravel(fare)) return false;
        balance -= fare;
        return true;
    }
    long long getBalance() const { return balance; }
};

int main() {
    long long proceduralBalance = 10000;
    proceduralDeduct(proceduralBalance, 2000);
    cout << "Procedural balance: Rs " << proceduralBalance/100 << '\n';

    SmartCard card(10000);
    card.deduct(2000);
    cout << "OOP balance: Rs " << card.getBalance()/100 << '\n';
    cout << "Both styles preserve minimum balance: "
         << (proceduralBalance >= MIN_REMAINING &&
             card.getBalance() >= MIN_REMAINING ? "Yes" : "No") << '\n';
}
