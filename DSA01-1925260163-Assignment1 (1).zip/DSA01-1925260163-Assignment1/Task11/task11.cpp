#include <iostream>
using namespace std;

enum class Zone { Inner, Middle, Outer };
constexpr long long FARE_PAISE[] = {1000, 2000, 3000};
constexpr long long MIN_BALANCE_PAISE = 5000;

long long getFare(Zone z, bool peak) {
    long long f = FARE_PAISE[static_cast<int>(z)];
    return peak ? f + f * 20 / 100 : f;
}

int main() {
    cout << "Recommended money type: long long paise\n";
    cout << "Recommended zone type: enum class Zone\n";
    cout << "Recommended design: private SmartCard balance and central fare function\n";
    cout << "Inner peak fare: Rs " << getFare(Zone::Inner, true)/100.0 << '\n';
    cout << "Outer peak fare: Rs " << getFare(Zone::Outer, true)/100.0 << '\n';
    cout << "Minimum remaining balance: Rs " << MIN_BALANCE_PAISE/100 << '\n';
    cout << "Journey processing time: O(1) per journey\n";
    cout << "Limitation: fares and rules require recompilation when hard-coded values change.\n";
}
