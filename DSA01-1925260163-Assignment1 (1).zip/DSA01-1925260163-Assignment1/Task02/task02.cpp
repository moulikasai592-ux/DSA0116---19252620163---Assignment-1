#include <iostream>
using namespace std;

enum class Zone { Inner, Middle, Outer };
constexpr long long FARES_PAISE[] = {1000, 2000, 3000};
constexpr int PEAK_PERCENT = 20;
constexpr long long MIN_BALANCE_PAISE = 5000;

int main() {
    Zone selected = Zone::Middle;
    long long base = FARES_PAISE[static_cast<int>(selected)];
    long long peakFare = base + base * PEAK_PERCENT / 100;
    cout << "Middle base fare: Rs " << base/100 << '\n';
    cout << "Middle peak fare: Rs " << peakFare/100 << '\n';
    cout << "Minimum remaining balance: Rs " << MIN_BALANCE_PAISE/100 << '\n';
}
