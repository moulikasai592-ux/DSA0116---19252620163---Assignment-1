#include <iostream>
#include <climits>
using namespace std;

int main() {
    const long long farePaise = 3000; // Rs 30.00
    const long long journeys = 3000000;
    long long collectionPaise = farePaise * journeys;

    cout << "sizeof(bool): " << sizeof(bool) << " byte(s)\n";
    cout << "sizeof(int): " << sizeof(int) << " byte(s)\n";
    cout << "sizeof(long long): " << sizeof(long long) << " byte(s)\n";
    cout << "INT_MAX: " << INT_MAX << '\n';
    cout << "Collection for 3000000 journeys at Rs 30: Rs "
         << collectionPaise/100 << '\n';
    cout << "Collection in paise: " << collectionPaise << '\n';
    cout << "32-bit int sufficient for paise total? "
         << (collectionPaise <= INT_MAX ? "Yes" : "No") << '\n';
}
