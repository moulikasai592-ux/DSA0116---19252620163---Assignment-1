#include <iomanip>
#include <iostream>
#include <string>
using namespace std;

enum class Zone { Inner, Middle, Outer, Invalid };

bool isPeak(int hour) {
    return (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20);
}
long long calculateFare(Zone zone, int hour) {
    long long base = 0;
    switch (zone) {
        case Zone::Inner: base = 1000; break;
        case Zone::Middle: base = 2000; break;
        case Zone::Outer: base = 3000; break;
        default: return -1;
    }
    if (isPeak(hour)) base += base * 20 / 100;
    return base;
}
string money(long long p) {
    return "Rs " + to_string(p/100) + "." + (p%100 < 10 ? "0" : "") + to_string(p%100);
}

int main() {
    struct Test { const char* name; Zone zone; int hour; };
    Test tests[] = {
        {"Inner off-peak", Zone::Inner, 11},
        {"Middle peak", Zone::Middle, 8},
        {"Outer peak", Zone::Outer, 17},
        {"10 AM boundary", Zone::Inner, 10},
        {"8 PM boundary", Zone::Outer, 20},
        {"Unknown zone", Zone::Invalid, 12}
    };

    for (const auto& t : tests) {
        long long f = calculateFare(t.zone, t.hour);
        cout << t.name << ": ";
        if (f < 0) cout << "Invalid zone\n";
        else cout << money(f) << '\n';
    }

    long long balance = 10000;
    long long total = 0;
    struct Journey { Zone z; int hour; };
    Journey five[] = {
        {Zone::Inner, 8}, {Zone::Middle, 12}, {Zone::Outer, 17},
        {Zone::Inner, 20}, {Zone::Middle, 9}
    };
    cout << "Five-journey card test:\n";
    for (const auto& j : five) {
        long long f = calculateFare(j.z, j.hour);
        if (f >= 0 && balance - f >= 5000) {
            balance -= f;
            total += f;
            cout << "Accepted " << money(f) << ", balance " << money(balance) << '\n';
        } else {
            cout << "Denied, balance " << money(balance) << '\n';
        }
    }
    cout << "Total deducted: " << money(total) << '\n';
}
