#include <iostream>
#include <array>
using namespace std;

enum class Zone { Inner, Middle, Outer, Airport };
constexpr array<long long, 4> FARE_PAISE = {1000, 2000, 3000, 6000};

class MonthlyPass {
    bool active;
    Zone first, second;
public:
    MonthlyPass(Zone a, Zone b) : active(true), first(a), second(b) {}
    bool covers(Zone z) const {
        return active && (z == first || z == second);
    }
};

long long calculateFare(Zone z, bool peak, bool weekend) {
    long long fare = FARE_PAISE[static_cast<int>(z)];
    if (weekend) return fare - fare * 10 / 100; // weekend discount replaces peak surcharge
    if (peak) return fare + fare * 20 / 100;
    return fare;
}

int main() {
    MonthlyPass pass(Zone::Inner, Zone::Middle);
    cout << "Airport normal fare: Rs " << calculateFare(Zone::Airport, false, false)/100 << '\n';
    cout << "Airport peak fare: Rs " << calculateFare(Zone::Airport, true, false)/100 << '\n';
    cout << "Airport weekend fare: Rs " << calculateFare(Zone::Airport, true, true)/100 << '\n';
    cout << "Pass covers Inner: " << (pass.covers(Zone::Inner) ? "Yes" : "No") << '\n';
    cout << "Pass covers Outer: " << (pass.covers(Zone::Outer) ? "Yes" : "No") << '\n';
    cout << "Weekend discount and peak surcharge combined? No\n";
}
